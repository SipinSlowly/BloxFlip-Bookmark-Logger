# Setup
all you need to do is go to line 24 and replace "YOURWEBHOOK" with your webhook. Then just go to your site and enter the fields and press send.


Made by KraziDev#9249 on Discord.
